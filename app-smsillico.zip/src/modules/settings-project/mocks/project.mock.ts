import type { ProjectInfo } from '../interfaces';

export const PROJECT_MOCK: ProjectInfo = {
  name: 'SMS Illíco',
  senderId: 'SMSILLICO',
  description: '',
};
